from flask import Flask, render_template_string, request, jsonify
import pandas as pd
import ta
import time
import matplotlib.pyplot as plt
import base64
from io import BytesIO
from iqoptionapi.stable_api import IQ_Option
from dotenv import load_dotenv
import os

# Carrega variáveis de ambiente do arquivo .env
load_dotenv()
EMAIL = os.getenv("IQ_EMAIL")
SENHA = os.getenv("IQ_SENHA")

# Conecta na conta (USE CONTA DEMO!)
I_want_money = IQ_Option(EMAIL, SENHA)
I_want_money.connect()

# Verifica conexão
if I_want_money.check_connect():
    print("Conectado com sucesso à IQ Option!")
    I_want_money.change_balance("practice")  # ou "REAL" para conta real
else:
    print("Erro ao conectar! Verifique email/senha.")
    exit()

# Flask app
app = Flask(__name__)

ATIVOS_DISPONIVEIS = ["EURUSD", "GBPUSD", "USDJPY", "EURJPY"]
TIMEFRAME = 1  # 1 minuto

HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Painel de Trading com IA</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-4">
    <div class="max-w-md mx-auto bg-white p-6 rounded-2xl shadow-xl">
        <h1 class="text-xl font-bold mb-4">Painel de Trading com IA</h1>
        <form method="get" action="/">
            <label class="block mb-2 font-semibold">Selecione o ativo:</label>
            <select name="par" onchange="this.form.submit()" class="w-full p-2 border rounded-xl mb-4">
                {% for ativo in ativos %}
                <option value="{{ ativo }}" {% if ativo == par %}selected{% endif %}>{{ ativo }}</option>
                {% endfor %}
            </select>
        </form>
        <p><strong>Par:</strong> {{ par }}</p>
        <p><strong>RSI Atual:</strong> {{ rsi }}</p>
        <p><strong>Sinal:</strong> <span class="font-semibold text-blue-600">{{ sinal }}</span></p>
        <div class="mt-4 flex gap-4">
            <form method="post" action="/comprar">
                <input type="hidden" name="par" value="{{ par }}">
                <button class="bg-green-500 text-white px-4 py-2 rounded-xl shadow">📈 Comprar</button>
            </form>
            <form method="post" action="/vender">
                <input type="hidden" name="par" value="{{ par }}">
                <button class="bg-red-500 text-white px-4 py-2 rounded-xl shadow">📉 Vender</button>
            </form>
        </div>
        {% if status %}
        <div class="mt-4 p-2 bg-gray-100 rounded-xl">
            <p><strong>Status da ordem:</strong> {{ status }}</p>
        </div>
        {% endif %}
        {% if chart %}
        <div class="mt-6">
            <img src="data:image/png;base64,{{ chart }}" class="rounded-xl shadow">
        </div>
        {% endif %}
    </div>
</body>
</html>
"""

def get_rsi(par):
    candles = I_want_money.get_candles(par, 60, 100, time.time())
    df = pd.DataFrame(candles)
    df['close'] = df['close'].astype(float)
    rsi = ta.momentum.RSIIndicator(df['close'], window=14).rsi().iloc[-1]
    if rsi < 30:
        sinal = "COMPRAR 🔼"
    elif rsi > 70:
        sinal = "VENDER 🔽"
    else:
        sinal = "AGUARDAR ⏳"
    return round(rsi, 2), sinal, df

def gerar_grafico_tendencia(df):
    plt.figure(figsize=(6,3))
    plt.plot(df['close'], label='Preço', color='black')
    # linha de tendência simples (reta ligando o primeiro e último ponto)
    plt.plot([0, len(df)-1], [df['close'].iloc[0], df['close'].iloc[-1]], 'r--', label='Tendência')
    plt.title("Linha de Tendência")
    plt.legend()
    plt.tight_layout()
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    imagem_base64 = base64.b64encode(buffer.getvalue()).decode()
    buffer.close()
    plt.close()
    return imagem_base64

@app.route("/", methods=["GET"])
def index():
    par = request.args.get("par", "EURUSD")
    rsi, sinal, df = get_rsi(par)
    chart = gerar_grafico_tendencia(df)
    return render_template_string(HTML, par=par, rsi=rsi, sinal=sinal, status=None, ativos=ATIVOS_DISPONIVEIS, chart=chart)

@app.route("/comprar", methods=["POST"])
def comprar():
    par = request.form.get("par", "EURUSD")
    I_want_money.buy(1, par, "call", TIMEFRAME)
    rsi, sinal, df = get_rsi(par)
    chart = gerar_grafico_tendencia(df)
    return render_template_string(HTML, par=par, rsi=rsi, sinal=sinal, status="Compra enviada", ativos=ATIVOS_DISPONIVEIS, chart=chart)

@app.route("/vender", methods=["POST"])
def vender():
    par = request.form.get("par", "EURUSD")
    I_want_money.buy(1, par, "put", TIMEFRAME)
    rsi, sinal, df = get_rsi(par)
    chart = gerar_grafico_tendencia(df)
    return render_template_string(HTML, par=par, rsi=rsi, sinal=sinal, status="Venda enviada", ativos=ATIVOS_DISPONIVEIS, chart=chart)

if __name__ == "__main__":
    app.run(debug=True)
