# Salve este conteúdo com o nome app.py e coloque na mesma pasta que o arquivo .env
# Ele será atualizado automaticamente via o editor de código.
